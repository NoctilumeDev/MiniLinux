# QEMU 9.2.2 对照轮报告（固定提交 4eac29a）

> 更正说明：本报告已按 CORRIGENDUM-922-4eac29a.md 修订。撤回"唯一变量是 QEMU"的严格单变量表述（两轮宿主 CPU 指纹不同）；补齐为三次非零尝试；二进制比较证据的核验范围以更正 3 为准。

## 结论（严格限定范围）

固定提交 `4eac29a6dc0ebf3802becb1fc291f085d2301290` 的官方 Linux 入口，在本次环境、这份 QEMU 9.2.2 下，已执行范围全部通过：doctor、run --stage M0、run（LAB）、check，以及 LAB 的 API 级体验。这个结论不自动推广到所有 QEMU ≥9 版本，也不单独证明某个上游补丁是唯一根因。

## 1. 环境

- 源码：4eac29a6dc0ebf3802becb1fc291f085d2301290；开始与结束 HEAD 相同，受跟踪文件零改动（19-final-git-status.txt 为 0 行）。
- 新独立目录：`/home/user/Doubao/chats/38447846951805954/repro-4eac29a/MiniLinux`。
- QEMU：9.2.2，路径 `/home/user/Doubao/chats/38447846951805954/MiniLinux/.toolroot/qemu-9.2.2/usr/local/bin/qemu-system-x86_64`，二进制 SHA256 `926fbd3d628f2cf0973d333070a27ade1504cc11a759e438078cf7f599e2129b`，自带 `../share/qemu` 固件。来源：上一轮（2026-10-17）由 download.qemu.org 官方 qemu-9.2.2.tar.xz 经 configure/ninja/ninja install 编译安装。**原始 tarball 与编译日志在 /tmp，已随沙箱重置清除，无法从现存文件再核验编译链，这部分不知道。**
- Python 3.12.11（/opt/python3.12）；venv 与 pycdlib 1.20.0 沿用旧轮（.tools/linux/venv，持久）；Limine 12.9.0 沿用，SHA256 与入口钉死值一致。
- 编译器：本轮两次环境阻断（沙箱重置清掉 /usr/bin 的 apt 包）。
  - doctor 首次尝试因缺 clang 退出 1（10-doctor-attempt1-missing-clang.log），按 docs 重新 apt 安装 clang/lld/llvm 14.0.0-1ubuntu1.1。
  - check 首次尝试又因缺 clang 退出 1（13-check-attempt1-missing-clang.log）。改为把同版本 Ubuntu 包（apt-get download 8 个 deb）**解压到项目内 .tools/linux/llvm14**，临时 PATH 前置其真实 bin 目录、临时 LD_LIBRARY_PATH 指向其库目录。没有包装脚本、没有覆盖 /usr/bin、没有改全局 PATH、没有改仓库代码或判据。docs 本身提供 --llvm-bin 这类工具解析机制，PATH 前置与其同机制；LD_LIBRARY_PATH 是额外必需的环境变量，记录于此。
- 最终 doctor 实际显示 QEMU 9.2.2 与本地 LLVM 路径（10b-doctor-local-llvm.log）。

## 2. 命令与退出码（被测入口的码，写入 .exitcode 文件，外层返回同码）

| 命令 | 退出码 | 状态 | 日志 |
| --- | --- | --- | --- |
| doctor（apt LLVM，首试） | 1 | 环境阻断（缺 clang，重置后） | 10-doctor-attempt1-missing-clang.* |
| doctor（本地 LLVM，LD_LIBRARY_PATH 为空） | 1（clang 127） | 调用错误（缺 libclang-cpp.so.14） | 10b-doctor-attempt2-empty-ldlib.* |
| check（apt LLVM，首试） | 1 | 环境阻断（第二次重置后缺 clang） | 13-check-attempt1-missing-clang.* |
| doctor（apt LLVM 恢复后） | 0 | 通过 | 10-doctor.log |
| run --stage M0（apt LLVM） | 0 | 通过 | 11-run-m0.log |
| run（LAB，apt LLVM） | 0 | 通过 | 12-run-lab.log |
| doctor（本地 LLVM 最终环境） | 0 | 通过 | 10b-doctor-local-llvm.log |
| check（QEMU 9.2.2 + 本地 LLVM） | 0 | 通过 | 13-check.log |

非零尝试共三次、环境重置共两次，二者的区分见 CORRIGENDUM-922-4eac29a.md 更正 2。

## 3. 原失败命令（双 counter）在 9.2.2 下的实际观察（12-run-lab.log、lab-trace.log）

- 8 秒窗口内返回：两条 counter 各完成 5 个 step，`run: pid 5 exited status 0`、`run: pid 6 exited status 0`，随后 `mini$` 出现，shell 接管。
- tick 推进：trace 最大 tick 563（6.2 轮全部为 0）。
- 时钟 schedule 事件：502 条，从 tick 48 起在 pid 5/6 间双向切换（6.2 轮 0 条）。
- counter 退出：pid 5 tick 547、pid 6 tick 548，各跑 250/251 个时间片，status 0。
- `run fault`：vector=14、pid 退出 142、shell 继续；`check` 观察命令输出 "user boundaries passed" 和 "process capacity and reclamation passed"；`mem` 正常。

以上都是日志实际记录。我没有挂 monitor/GDB，也不据此推断任务每一瞬间的运行状态——这些是事件流与控制台的直接内容。

证据留痕说明：`run(LAB)`（pid 5/6）的 502 条 schedule、max tick 563 是当时读取 build/lab-trace.log 得到的数值；该文件被入口后续客体（check 桥接、实时 LAB）覆盖重写，原文件未单独归档，其控制台输出保留在 12-run-lab.log。证据包内现存的 lab-trace.log 是实时 LAB 客体（pid 3/4）：max tick 9137、501 条 schedule、counter pid 3/4 退出 status 0、fault pid 5 退出 142，独立复现了同一行为。

## 4. check 的实际计数（从记录计算，不混算）

- 串口案例 36 个（build/linux-checks/*-serial.log）：M0–M6 各 64/256M 共 14；M6 attack 1–5 各两档共 10；M6 fault 2–7 各两档共 12。全部 SERIAL PASS。
- attack-3 额外 OOM 深度证据 3 条（spare pages=0/1/2 rejected，在 256m 日志）。
- test-userland.py：2 个内存档（64/256），各含双 counter、双向切换、fault 142、24 次顺序程序运行、页面恢复（userland-results.json）。
- test-lab-bridge.py：16 条 HTTP 检查（bridge-results.json），含 stop/restart 两次客体生命周期。
- test-lab-boundaries.py：baseline 2 档 + fixture 2 档（supplemental/*-results.json）。
- QEMU 启动次数：check 内 36 个串口客体 + userland 2 + bridge 2 + boundaries 4 = 44；另有 run --stage M0 1 次、run(LAB) 1 次、lab 体验 1 次。全部由入口回收。

## 5. 新旧载荷对照（是否同一镜像）

- 关键对照：6.2 失败轮与 9.2.2 的 run(LAB) 使用的 kernel.elf 哈希都是 `2dd65a6a…`，user.bin 都是 `ca3b16e8…`。即相同内核 ELF 在两份记录环境中，6.2 轮双 counter 失败、9.2.2 轮通过。**两轮宿主 CPU 指纹不同（sapphirerapids 对 znver3），"唯一变量是 QEMU"的表述已撤回，见 CORRIGENDUM-922-4eac29a.md 更正 1。**
- check 用本地 LLVM 构建的 kernel.elf 哈希不同（M0 为 1c1846…、LAB 为 c4a79d1f…）。已定位差异：**仅调试段里 clang 资源头文件路径不同**（`/usr/lib/llvm-14/lib/clang/14.0.0/include` 对 `.tools/linux/llvm14/.../include`）。strip 掉调试信息后 M0 ELF 两轮哈希同为 61d29b47、LAB ELF 同为 7d116c3c，可加载代码逐字节一致。
- ISO 整文件字节级跨轮一致性未做：9.2.2 的 run(LAB) ISO 已被 check 覆盖，未单独保留；入口每次都校验 ISO 内存载荷与本轮 kernel.elf/limine.conf/limine-bios.sys 一致。因此声称的是"载荷一致"，不声称 ISO 整包字节相同（ISO 可能含时间戳）。

## 6. 实时 LAB（通过检查后执行）

- 官方入口 `tools/linux.py lab --port 18923`；8080 被沙箱 nginx 占用，按入口自带 --port 换到 18923，未动其他服务。
- 通过回环 API 观察：cat hello.txt 读到 "hello from ramfs"；双 counter 各 5 步退出、提示符返回；run fault 隔离退出 142、之后 ps 正常；首页 HTTP 200。
- **浏览器体验未执行**（云端无本机浏览器），以上均为 API/HTTP 级结果，不构成网页试玩。

## 7. 收尾

- LAB 进程台账 3287/3336/3337（见 18-cleanup.txt）：/api/stop 返回 okay，按 PID 逐个 TERM，停止后端口 18923 无监听、三进程均无；沙箱 8080 未受影响。
- check 的 44 个客体由入口自身回收，check 结束后无残留。

## 8. 未执行 / 不知道

- 浏览器手动试玩未执行；GDB 现场篡改与仓库外 monitor 组件不在本入口范围（入口自己声明）。
- 其他 QEMU 版本（如 Noble 自带 8.2、9.0、9.1）未测，是否通过不知道。
- 9.2.2 二进制的原始编译链文件已随 /tmp 清除，无法重新核验来源。
- 根因归因仍以上一轮源码对比与上游 commit c2e6d7d8e7fc 为旁证；本轮独立证明的是"同一内核二进制在 6.2 挂、9.2.2 过"，不证明该补丁是唯一根因。
