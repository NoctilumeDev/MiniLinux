# 更正补充（CORRIGENDUM）— QEMU 9.2.2 对照轮

本文件只更正 REPORT-922-4eac29a.md 的表述，未重跑任何命令、未改代码。最终功能通过、6.2 轮历史失败、以及"不知道"的部分均保留。

## 更正 1：撤回"唯一变量是 QEMU"的严格单变量表述

日志原文：
- 旧轮 07-doctor.log（归档于 build/archive-qemu62/repro-logs/）：LLVM 工具 `Host CPU: sapphirerapids`。
- 新轮 10-doctor.log、10b-doctor-local-llvm.log：`Host CPU: znver3`。

这是 LLVM 工具运行时打印的宿主 CPU 指纹，说明两轮记录的宿主 CPU 暴露不同。我没有保留当时环境迁移、实例变化或 CPU 暴露变化的独立记录（00-env.txt 只记路径，没有迁移事件；所有当时日志里只有 doctor 各自打印的指纹）。变化何时、因何发生，**不知道**。

因此不能再称"唯一变量是 QEMU"或已确认的严格单变量实验。结论改为：

> 相同内核 ELF（kernel.elf 2dd65a6a、user.bin ca3b16e8）在两份记录环境中，6.2 轮（Host CPU 指纹 sapphirerapids）双 counter 失败，这份 QEMU 9.2.2（Host CPU 指纹 znver3）双 counter 通过。

QEMU 版本与宿主 CPU 指纹两个差异同时存在，本轮无法把它们的影响分开。

## 更正 2：两次环境重置与三次失败尝试分开记录

环境重置（/usr 内容被清，现象是 apt 装的 clang 消失）：**两次**。
非零退出的失败尝试：**三次**，彼此独立：

| 失败尝试 | 现象 | 直接退出码 | 被测入口退出码 | 日志 |
| --- | --- | --- | --- | --- |
| 1 | 第一次重置后缺 clang，doctor 调 clang --version 失败 | 1 | 1 | 10-doctor-attempt1-missing-clang.log(.exitcode=1) |
| 2 | 用本地解压 LLVM 时未设 LD_LIBRARY_PATH，clang 加载 libclang-cpp.so.14 失败 | clang 127 | 1 | 10b-doctor-attempt2-empty-ldlib.log(.exitcode=1) |
| 3 | 第二次重置后缺 clang，check 失败 | 1 | 1 | 13-check-attempt1-missing-clang.log(.exitcode=1) |

尝试 2 是我自己的环境变量调用问题，不是重置。三次失败均被后续成功命令保留下来，最终成功不覆盖它们。

## 更正 3：二进制比较证据的范围

已交付的证据包内**没有** ELF、strip 比较输出或比较记录文件。"差异仅在调试段、strip 后相同"的原始依据是本次会话中执行的比较命令（终端输出，当时未写入证据包）。比较时生成的 8 个中间文件仍在 /tmp，时间戳为 14:16（早于本更正请求，未重新生成）；本次仅以只读方式重新哈希，值与当时输出逐项一致。现把当时命令与输出原样转录如下。

M0 比较：
- 从 6.2 轮归档 ISO 抽出的 kernel.elf：76e25904362a0db6aaa35ab56ac05db081ee97c1b164c8591138d9d6b36ff4f3
- 本地 LLVM 构建的 kernel.elf：1c1846c4472dea2fa643d91f8db28dfb868ae60659b1d9436d82d508d97acb87
- 两者 `llvm-objcopy --strip-debug` 后同为：61d29b4773c5ad7c154b580995b9c4fb780ec11e99b3650612e8977bb1ed90a8

LAB 比较：
- 6.2 轮归档 kernel.elf：2dd65a6afa0d1bdcb6e8cb977938d8d828dfb868ae60659b1dee59b8b000b8e36d27
- check 轮 ISO 内 kernel.elf：c4a79d1f36010e27dd3fd18c836540f5b4ca1fc99f4657a73e19b3f268bee318
- strip 后两者同为：7d116c3caa9ca00e2bdeb5f4e0536d4a9bc21394c09d387623787cd40f752bb4

差异定位（strings 调试段）：62 轮为 `/usr/lib/llvm-14/lib/clang/14.0.0/include`，本地轮为 `.tools/linux/llvm14/usr/lib/llvm-14/lib/clang/14.0.0/include`；DWARF 的 DW_AT_producer 与 DW_AT_comp_dir 两轮相同。

证据等级标注：最初交付的证据包无法独立核验该结论。本更正将 14:16 比较时生成的 8 个中间文件（mtime 为 14:16，早于本更正请求，从 /tmp 原样只读复制、未重新生成）连同 MANIFEST（哈希清单）一并收入证据包 repro922-logs/comparison-artifacts/，现在可独立核验 strip 后哈希；但"比较命令本身当时执行"这一事实仍只由会话记录和文件 mtime 支持，无法事后重放。

## 更正 4：两个客体分开（不互相替代）

- run(LAB) 的双 counter 客体（pid 5/6）：原始 trace 未单独留存（被入口后续客体覆盖），502 条 schedule、max tick 563 是当时读取值；其控制台输出在 12-run-lab.log。
- 交付证据包里现存的 lab-trace.log 属于实时 LAB 客体（pid 3/4）：501 条 schedule、max tick 9137、pid 3/4 退出 status 0、fault pid 5 退出 142。
- 两者是独立客体的独立记录，分别保留，不互相替代。

## 不变的部分

- 功能通过范围不变：doctor、M0、run、check 退出码 0；实时 LAB 的 API 级观察通过。
- 6.2 轮历史失败结论不变。
- 浏览器体验未执行、其他 QEMU 版本未测、9.2.2 编译来源链无法再核验，仍为不知道。
